#include <iostream>
#include "../src/AES.h"

int main(int argc, char *argv[])
{
  cout << "Aes dev" << endl;
  return 0;
}